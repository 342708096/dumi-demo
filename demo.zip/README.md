# LEGO-HOOKS

## 开发流程

在你 clone 代码并且使用 `yarn run init` 安装完依赖后，你还可以运行下面几个常用的命令：

1. `yarn start` 在本地运行网站。

2. `yarn run test` 运行测试。

3. `yarn run build` 构建编译。

## 📦 安装

```bash
$ npm install --save legohooks
# or
$ yarn add lego-hooks
```

## 🔨 使用

```js
import { xxx } from 'lego-hooks';
```
