const packages = require('../package.json');
const base =
  process.env.NODE_ENV === 'production' ? `/site/${packages.pid}/${packages.version}/index/` : '/';

const publicPath =
  process.env.NODE_ENV === 'production'
    ? `//file.ljcdn.com/nebula/kegem/site/${packages.pid}/${packages.version}/`
    : '/';
console.log('base===🚀===>', base);
console.log('publicPath===🚀===>', publicPath);
export default {
  // ssr: {},
  exportStatic: {}, // 根据路由按文件夹结构输出所有 HTML
  nodeModulesTransform: {
    type: 'none',
    exclude: [],
  },
  outputPath: '_site',
  base,
  publicPath,
  extraBabelPlugins: [
    [
      'babel-plugin-import',
      {
        libraryName: 'antd',
        libraryDirectory: 'es',
        style: true,
      },
      'antd',
    ],
    [
      'babel-plugin-import',
      {
        libraryName: '@alifd/next',
        style: false,
      },
      'fusion',
    ],
  ],
  mode: 'site', // site
  title: 'lego-hooks',
  favicon: 'https://img.ljcdn.com/beike/ked/1617095504422.png',
  logo: 'https://img.ljcdn.com/beike/ked/1617095504422.png',
  dynamicImport: {},
  manifest: {},
  hash: true,
  resolve: {
    includes: ['docs', 'src'],
  },
  links: [
    {
      rel: 'stylesheet',
      href: 'https://unpkg.com/@alifd/theme-design-pro@0.6.2/dist/next-noreset.min.css',
    },
    { rel: 'stylesheet', href: `${publicPath}style.css` },
  ],
  navs: [
    { title: '指南', path: '/guide' },
    { title: 'Hooks', path: '/hooks' },
  ],
  menus: {
    '/': [
      {
        title: '首页',
        path: 'index',
      },
    ],
    // '/guide': [
    //   {
    //     title: '介绍',
    //     path: '/guide',
    //   }
    // ],
    // '/hooks': menus,
  },
  headScripts: [
    {
      src: '//unpkg.com/react@16.14.0/umd/react.development.js',
    },
    {
      src: '//unpkg.com/react-dom@16.14.0/umd/react-dom.development.js',
    },
    `
      window.publicPath = "${publicPath}"
    `,
  ],
  scripts: [
    `
  const insertVersion = function(){
    const logo = document.querySelector('.__dumi-default-navbar-logo');
    if(logo){
      logo.innerHTML = logo.innerHTML + '@${packages.version}'
    }else{
      setTimeout(()=>{
        insertVersion();
      }, 1000)
    }
  }
  insertVersion();
  `,
  ],
};
