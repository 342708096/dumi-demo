import * as React from 'react';
import './homepage.less';

class HomePage extends React.Component {
  render() {
    return (
      <div className="cover-wrapper">
        <div className="cover-content">
          <div className="cover-icon">
            <img src="//img.ljcdn.com/beike/ked/1617095504422.png" alt="" />
          </div>
          <h3>lego-hooks</h3>

          <a className="start" href={`${(window as any).routerBase}guide`}>
            开始使用
          </a>

          <div className="slogan">
            装修 h5 组件库，基于 ked-m 和 antd-mobile 与装修业务高度相关的业务组件库
          </div>
        </div>
      </div>
    );
  }
}

export default HomePage;
