
## 安装

```bash
$ npm install --save @ke/lego-hooks
# or
$ yarn add @ke/lego-hooks
```

## 使用

```ts
import { xxx } from '@ke/lego-hooks';
```
