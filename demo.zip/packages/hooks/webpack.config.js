const merge = require('webpack-merge');
const common = require('../../webpack.common.js');
const path = require('path');
console.log(merge);
module.exports = merge(common, {
  entry: './es/index.js',
  output: {
    filename: 'lego-hooks.js',
    library: 'lego-hooks',
    path: path.resolve(__dirname, './dist'),
  },
});
